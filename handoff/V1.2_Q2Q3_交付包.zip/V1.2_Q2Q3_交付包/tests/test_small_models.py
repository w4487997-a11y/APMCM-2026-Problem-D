# -*- coding: utf-8 -*-
"""执行书 Q2-03 / Q3-02 要求的小样例逐状态核对。

Q2 小例：2 个 A × 2 个 B = 4 变量，枚举 16 个状态，核对公式与矩阵一致、
        并检查禁用原最优后次优合法解。
Q3 小例：2A × 2B × 3X = 8 变量（u 6 + b 2），枚举 256 个状态，同上。

运行：python test_small_models.py
"""

import itertools
import json
import os

import numpy as np

OUT = os.path.dirname(os.path.abspath(__file__))


def build_q2(cost, lam=2.0, M=2.0):
    n = 4                      # a0,a1,b0,b1
    Q = np.zeros((n, n))
    const = 2 * lam
    Q[0, 0] = Q[1, 1] = -lam
    Q[2, 2] = Q[3, 3] = -lam
    Q[0, 1] = 2 * lam
    Q[2, 3] = 2 * lam
    for i in range(2):
        for j in range(2):
            Q[i, 2 + j] += cost[i][j]
    return Q, const


def build_q3(cost, lam=2.0):
    # cost[i][j][k]；u_(i,k) = i*3+k；b_j = 6+j
    n = 8
    Q = np.zeros((n, n))
    const = 2 * lam
    for i in range(6):
        Q[i, i] = -lam
    for j in range(2):
        Q[6 + j, 6 + j] = -lam
    for i in range(6):
        for j in range(i + 1, 6):
            Q[i, j] = 2 * lam
    Q[6, 7] = 2 * lam
    for i in range(2):
        for k in range(3):
            for j in range(2):
                Q[i * 3 + k, 6 + j] += cost[i][j][k]
    return Q, const


def energy(Q, const, bits):
    x = np.array(bits, dtype=float)
    return float(const + x @ Q @ x)


def formula_q2(cost, bits, lam=2.0, M=2.0):
    a0, a1, b0, b1 = bits
    val = cost[0][0] * a0 * b0 + cost[0][1] * a0 * b1 \
        + cost[1][0] * a1 * b0 + cost[1][1] * a1 * b1
    val += lam * (a0 + a1 - 1) ** 2 + lam * (b0 + b1 - 1) ** 2
    return val


def formula_q3(cost, bits, lam=2.0):
    u = bits[:6]
    b = bits[6:]
    val = 0.0
    for i in range(2):
        for k in range(3):
            for j in range(2):
                val += cost[i][j][k] * u[i * 3 + k] * b[j]
    val += lam * (sum(u) - 1) ** 2 + lam * (sum(b) - 1) ** 2
    return val


def main():
    report = {}

    cost2 = np.array([[0.10, 0.80], [0.60, 0.20]])
    Q2, c2 = build_q2(cost2)
    states = list(itertools.product([0, 1], repeat=4))
    diffs, feasible = [], []
    for s in states:
        e, f = energy(Q2, c2, s), formula_q2(cost2, s)
        diffs.append(abs(e - f))
        if sum(s[:2]) == 1 and sum(s[2:]) == 1:
            feasible.append((cost2[s[0]][s[2]] if False else
                             cost2[0 if s[0] else 1][0 if s[2] else 1], s, e))
    best = min(feasible, key=lambda t: t[0])
    report["q2_small"] = {
        "states": len(states),
        "max_abs_energy_diff": float(np.max(diffs)),
        "passed_formula": bool(np.max(diffs) < 1e-12),
        "feasible_states": len(feasible),
        "optimal_bits": list(best[1]),
        "optimal_energy": float(best[2]),
        "optimal_cost": float(best[0]),
    }
    # 禁用原最优后，次优合法解
    feasible_sorted = sorted(feasible, key=lambda t: t[0])
    report["q2_small"]["second_best_bits"] = list(feasible_sorted[1][1])
    report["q2_small"]["second_best_cost"] = float(feasible_sorted[1][0])

    # Q3：cost[i][j][k]
    cost3 = np.arange(12, dtype=float).reshape(2, 2, 3) / 10.0
    Q3, c3 = build_q3(cost3)
    states3 = list(itertools.product([0, 1], repeat=8))
    diffs3, feas3 = [], []
    for s in states3:
        e, f = energy(Q3, c3, s), formula_q3(cost3, s)
        diffs3.append(abs(e - f))
        if sum(s[:6]) == 1 and sum(s[6:]) == 1:
            u = s[:6].index(1)
            j = s[6:].index(1)
            base = u // 3
            k = u % 3
            feas3.append((cost3[base][j][k], s, e))
    best3 = min(feas3, key=lambda t: t[0])
    report["q3_small"] = {
        "states": len(states3),
        "max_abs_energy_diff": float(np.max(diffs3)),
        "passed_formula": bool(np.max(diffs3) < 1e-12),
        "feasible_states": len(feas3),
        "optimal_bits": list(best3[1]),
        "optimal_energy": float(best3[2]),
        "optimal_cost": float(best3[0]),
    }
    report["all_passed"] = bool(report["q2_small"]["passed_formula"]
                                and report["q3_small"]["passed_formula"])

    print(json.dumps(report, ensure_ascii=False, indent=2))
    with open(os.path.join(OUT, "test_small_models_result.json"), "w", encoding="utf-8") as fh:
        json.dump(report, fh, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
