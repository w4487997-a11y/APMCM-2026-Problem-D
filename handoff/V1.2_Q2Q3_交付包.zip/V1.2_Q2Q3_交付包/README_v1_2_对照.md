# V1.2 执行书 · Q2/Q3 交付对照表

生成时间：2026-11-27 19:40（北京时间）
依据：`APMCM_D_final_execution_V1.2.md` 第 07–10、12 章
数据：官方 V1.2 预测表（`q2_pool_predictions.csv` 2,704 行、`q3_pool_predictions.csv` 8,112 行）

---

## 一、逐条验收

| 执行书条目 | 状态 | 交付文件 | 证据 |
|---|---|---|---|
| Q2-01 合法候选与代价 | **PASS** | `q2_qubo.npz`、`q2_oracle.csv` | 2,704 个合法候选，原始 `raw_V_hat`、缩放代价、缩放参数齐全 |
| Q2-02 独热编码与证明 | **PASS** | `q2_mapping.json` | 上三角约定、λ=2、M=2、offset=4、变量顺序 |
| Q2-03 能量与约束验收 | **PASS** | `q2_energy_audit.json`、`tests/` | 能量与代价最大偏差 0；最优集合一致；非法态最小能量 2.0 > 合法最大 1.0；2×2 小例 16 态全核对 |
| Q3-01 建模与资源 | **PASS** | `q3_qubo.npz`、`q3_mapping.json` | 208 逻辑变量，非零耦合 21,735（理论上限 21,528 含对角） |
| Q3-02 程序验收 | **PASS** | `q3_energy_audit.json`、`tests/` | 8,112 合法态逐条核对；2A×2B×3X 小例 256 态；u→(A,X) 解码验证 |
| Q3-03 107 变量投影 | **PENDING** | — | 未实施，不影响主线 |
| K-01 Kaiwu SDK 建模 | **PENDING** | `hardware_jobs.json` | 未安装 SDK；矩阵由 numpy 生成后经**云平台控制台上传**执行。按执行书要求，**不得称为已用 Kaiwu 建模** |
| K-02 QUBO→Ising 与能量验证 | **PASS**（numpy 复算） | `ising_q2.npz`、`ising_q3.npz`、`ising_equivalence.csv` | 抽样 2,000 个合法态，Ising 与 QUBO 能量最大偏差 2.0e-12 / 5.2e-12 |
| K-03 本地求解与真机 | **PARTIAL** | `solver_runs.csv`、`decoded_samples.csv`、`solver_report.md` | 2 次真机任务完成；"每配置 30 次重复运行"未做 |
| S-01 精度适配与惩罚扫描 | **PARTIAL** | `precision_sweep.csv` | 6 组 λ 浮点扫描 + 4 组 8 位量化；**变量拆分未做**（需 SDK） |
| S-02 四层误差与成本 | **PARTIAL** | `error_attribution.csv`、`resource_cost.csv`、`cost_report.md` | 映射/量化/采样三层有数；代理误差层待 Q1 |
| 论文 Q2/Q3 章节 | **PASS**（中文草稿） | `论文_Q2Q3_章节草稿.docx` | 8 章，含真机验证与量化分析；英文版 PENDING |

---

## 二、关键数字

### 2.1 浮点模型（全池）

| | 问题二（07 池） | 问题三（08 池） |
|---|---|---|
| 合法候选 | 2,704 | 8,112 |
| 逻辑变量 | 104 | 208 |
| 非零耦合 | 5,459 | 21,735 |
| 最优 | **Y–Ti** | **Na–Nb–O3** |
| 最优 V̂ | 1.49193 | 0.54002 |
| 次优 | Y–Zr 1.80575 | Sn–Ti–O3 0.55315 |
| 首位间隔 | 0.31382 | 0.01312 |
| 能量核对 | 偏差 0 | 偏差 0 |
| 罚项充分性 | 2.0 > 1.0 | 2.0 > 1.0 |

### 2.2 8 位量化

| | 问题二 | 问题三 |
|---|---|---|
| 统一缩放 LSB | 2.09 V̂ | 2.12 V̂ |
| 全量矩阵基态并列 | 6 个 | 21 个 |
| 截断 Δ=0.4、λ=1.02 后 | 唯一，argmin 保留 | 唯一，argmin 保留 |
| 代价 LSB（截断版） | 0.00643 | 0.00643 |

### 2.3 真机（SPQC-550，云平台上传）

| | q2_int_01 | q3_int_01 |
|---|---|---|
| 矩阵 | 17 变量短名单，`|h|`=110 | 30 变量短名单，`|h|`=100 |
| 任务 ID | 76ac237a…8c4e98 | 7ab4ca36…f92869 |
| 创建→结束 | 4 秒 | 19 秒 |
| 单次演化 | 1.1228 ms | 8.7755 ms |
| 返回样本 | 10（1 合法） | 10（1 合法） |
| 最优解 | **Y–Ti**（= 全局最优） | **Ge–Ti–O3**（X=O3 ✓，A–B 精度受限） |
| 额度 | 1 | 1 |

---

## 三、必须如实声明的三点

1. **未使用 Kaiwu SDK 建模与求解。** 两次真机任务通过网页控制台上传整数矩阵执行；矩阵由 numpy 生成。执行书 K-01 明确禁止把此举称为"已使用 Kaiwu 建模"。
2. **真机只跑了短名单。** 全池 104 / 208 变量的 Ising 场项 `h ≈ 1550`，远超 8 位上限 127，无法直接提交；短名单把一热宽度压到 9×8 与 8×3×6 后才满足约束。
3. **问题三真机只能确认 X = O3。** A–B 位的前三名间隔 0.013~0.064 小于本次矩阵分辨率 0.15，量化后同能量，返回 Ge–Ti–O3 属同能量集合中的一员，不能宣称唯一最优。

---

## 四、复现

```bash
# 1. 重建全池矩阵并做能量/最优/罚项审计
python build_v12_deliverables.py

# 2. 小样例逐状态核对（16 态 / 256 态）
python tests/test_small_models.py

# 3. 解码真机日志（在 q2_project/ 下）
python decode_solution.py --meta platform_upload/qubo_q2_intising_meta.json \
       --solution platform_upload/q2_int_01.log
python decode_solution.py --meta platform_upload/qubo_q3_intising_meta.json \
       --solution platform_upload/q3_int_01.log
```

---

## 五、尚缺（按优先级）

| 优先级 | 缺口 | 影响 | 建议 |
|---|---|---|---|
| P0 | Kaiwu SDK 安装与 SDK 路径建模 | 执行书 K-01 无法标 PASS | 装 SDK 后用 `kw.core` 重建同一矩阵，留存 API 调用日志 |
| P0 | 04 的 3,703 条预测（Q1 交付） | 论文 Q1 章节 | A 侧负责，本包不含 |
| P1 | 每配置 30 次重复采样基线 | K-03 只能算 PARTIAL | 额度充足（余 28 次），可补 |
| P1 | 107 变量投影对照 | Q3-03 为 P1，不阻塞 | 时间允许再做 |
| P1 | 英文论文 | 提交语言 | 中文草稿可直接转写 |
