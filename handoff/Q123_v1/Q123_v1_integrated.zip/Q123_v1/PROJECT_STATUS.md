# 当前整合版状态

整合技术版固定使用 hgb_gap_mix v1 和 V1.2 接口。原版 Q1 的五池推理逐行核对，Q2/Q3 使用其中 07/08 完成本地 Kaiwu SDK 求解和独立能量复算。运行文件按标签留档，完整读取方式见 [交付说明](README.md)。

[整合决策和新实验](evidence/INTEGRATION_RECORD.md) · [上游决策](DECISIONS.md) · [上游实验记录](EXPERIMENT_LOG.md) · [合稿数据](paper/PAPER_EVIDENCE.md)
