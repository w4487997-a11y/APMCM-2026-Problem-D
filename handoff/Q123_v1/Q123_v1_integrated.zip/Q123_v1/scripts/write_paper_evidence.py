"""Export paper tables and a figure from the independently checked release runs."""
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
PAPER=ROOT/'paper'
RUNS=ROOT/'q23/runs'

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def table(path, rows):
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,list(rows[0]))
        w.writeheader()
        w.writerows(rows)

def main():
    q1_file=ROOT/'handoff/v1/validation_metrics.csv'
    with q1_file.open(encoding='utf-8-sig',newline='') as f:
        metrics=next(x for x in csv.DictReader(f) if x['model']=='hgb_gap_mix')
    q1_fields=('model','split','rows','mae','rmse','spearman',
               'top_10_overlap_count','top_25_overlap_count','top_50_overlap_count','top_100_overlap_count')
    table(PAPER/'q1_validation.csv',[{k:metrics[k] for k in q1_fields}])
    runs=[('Kaiwu SDK','sdk_v1_frozen_30x10'),('Local SA','local_v1_frozen_30x10')]
    values=[]
    series=[]
    for label,tag in runs:
        run=RUNS/tag
        checks=read(run/'verification.json')
        summary=read(run/'summary.json')
        assert checks['samples_verified']==1200
        stage=[]
        for question in ('q2','q3'):
            for model,entry in zip(checks['results'][question],summary['results'][question]['models'],strict=True):
                score=model['best']
                optimum=entry['enumeration_optimum']['V_hat']
                values.append({
                    'run_id':tag,'backend':label,'question':question.upper(),'X':model['group'],
                    'pool':summary['results'][question]['intake']['pool'],
                    'candidates':model['candidates'],'logical_variables':model['model_shape'][0],
                    'legal_samples':model['legal'],'returned_samples':model['samples'],
                    'legal_sample_fraction':model['legal']/model['samples'],
                    'attempts_with_optimum':model['attempts_with_optimum'],
                    'attempts':summary['args']['seeds'],'attempt_kind':entry['solver']['attempt_kind'],
                    'candidate_id':model['id'],'material':model['material'],
                    'best_returned_V_hat':score,'enumerated_V_hat':optimum,'gap_to_enumeration':score-optimum,
                    'solver_seconds':entry['wall_s'],
                })
                stage.append(values[-1])
        series.append(stage)
    table(PAPER/'q23_experiment_table.csv',values)
    fig, axes=plt.subplots(1,2,figsize=(10,3.6),layout='constrained')
    x=np.arange(4)
    colors=['#245b78','#83a889']
    labels=['Q2 / NO2','Q3 / O3','Q3 / NO2','Q3 / FO2']
    panels=[('Legal returned samples','legal_samples','returned_samples'),
            ('Attempts hitting the group minimum','attempts_with_optimum','attempts')]
    for ax,(title,num,den) in zip(axes,panels,strict=True):
        for idx,stage in enumerate(series):
            bars=ax.bar(x+(idx-.5)*.34,[100*r[num]/r[den] for r in stage],.32,color=colors[idx],
                        label=runs[idx][0],zorder=3)
            ax.bar_label(bars,[f'{r[num]}/{r[den]}' for r in stage],fontsize=8,padding=3,zorder=5)
        ax.set_xticks(x,labels,fontsize=8)
        ax.set_ylim(0,116)
        ax.set_yticks(np.arange(0,101,25),[f'{v}%' for v in np.arange(0,101,25)])
        ax.grid(axis='y',color='#dde3e8',linewidth=.8,zorder=0)
        ax.set_title(title,loc='left',fontsize=11,pad=10,fontweight='bold')
        for name in ('right','top'):
            ax.spines[name].set_visible(False)
    axes[0].legend(loc='upper right',frameon=False,fontsize=8)
    fig.savefig(PAPER/'q23_run_comparison.png',dpi=220)
    fig.savefig(PAPER/'q23_run_comparison.svg')
    plt.close(fig)

if __name__=='__main__':
    main()

