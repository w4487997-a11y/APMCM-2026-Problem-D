"""Check a Q2/Q3 run against frozen inputs and independently decoded raw samples."""
import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
FROZEN = ROOT/'handoff/v1_2'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def records(path):
    with path.open(encoding='utf-8-sig',newline='') as stream:
        return list(csv.DictReader(stream))

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))

def verify_model(run, row, prediction, family, attempts_requested):
    artifact=row['artifacts']
    for file in artifact.values():
        assert digest(run/file['file'])==file['sha256']
    with np.load(run/artifact['matrix']['file'],allow_pickle=False) as data:
        q,M,offset=data['qubo'],data['ising_adapted'],float(data['offset'])
        i,j,ids,values=(data[k] for k in ('left_idx','right_idx','candidate_id','raw_scores'))
        names=data['var_names'].tolist()
    assert hashlib.sha256(np.ascontiguousarray(q).tobytes()).hexdigest()==row['matrix_sha256']
    assert q.shape==(104,104) and M.shape==(105,105) and len(ids)==2704
    assert np.array_equal(q,np.triu(q)) and np.array_equal(M,M.T)
    assert offset==4 and np.all(np.diag(q)==-2)
    for block in (q[:52,:52],q[52:,52:]):
        assert np.all(block[np.triu_indices(52,1)]==4)
    assert np.all(q[:52,52:]>=0)
    assert len(set(zip(i.tolist(),j.tolist())))==52**2
    assert set(ids)=={k for k,r in prediction.items() if r['X']==family}
    J=np.triu(q,1)/4
    h=np.diag(q)/2+(J+J.T).sum(axis=1)
    independent=np.zeros_like(M)
    independent[:-1,:-1]=-(J+J.T)/2
    independent[:-1,-1]=independent[-1,:-1]=-h/2
    assert np.array_equal(M,independent)
    assert np.max(abs(h))==102 and np.max(abs(J))==1
    assert np.array_equal(h,np.rint(h)) and np.array_equal(J,np.rint(J))
    K=offset+np.trace(q)/2+J.sum()
    legal_all=q[i,j]+q[i,i]+q[j,j]+offset
    assert legal_all.min()==0 and sum(legal_all==0)==1 and legal_all[int(values.argmin())]==0
    lookup={}
    for a,b,identity,value in zip(i,j,ids,values,strict=True):
        candidate=prediction[int(identity)]
        assert names[a]==f"a:{candidate['A']}" and names[b]==f"b:{candidate['B']}"
        assert float(candidate['V_hat'])==value
        lookup[(int(a),int(b))]=(float(value),int(identity),'|'.join(candidate[k] for k in ('A','B','X')))
    returned=records(run/artifact['samples']['file'])
    spins=np.array([list(map(int,r['spin'].split())) for r in returned],dtype=int)
    assert spins.shape==(len(returned),105) and np.isin(spins,[-1,1]).all()
    bits=(1+spins[:,:-1]*spins[:,-1:])//2
    energy_q=np.einsum('si,ij,sj->s',bits,q,bits)+offset
    energy_i=-np.einsum('si,ij,sj->s',spins,M,spins)+K
    assert np.array_equal(energy_q,energy_i)
    found=[]
    hits=set()
    for row_csv,bit in zip(returned,bits,strict=True):
        hit=lookup.get(tuple(np.flatnonzero(bit)))
        attempt=int(row_csv['attempt'])
        assert 0<=attempt<attempts_requested
        if hit is None:
            assert (row_csv['legal'],row_csv['candidate_id'],row_csv['material'],row_csv['V_hat'])==('False','','','')
        else:
            value,candidate_id,mat=hit
            assert row_csv['legal']=='True'
            assert (float(row_csv['V_hat']),int(row_csv['candidate_id']),row_csv['material'])==hit
            found.append(hit)
            if abs(value-values.min())<1e-12:
                hits.add(attempt)
    claimed=row['solver']
    assert claimed['samples']==len(returned) and len(found)==claimed['legal_samples']
    assert len(hits)==claimed['seeds_with_legal_hit']
    score,identity,material=min(found)
    assert score==claimed['best_returned_V_hat'] and identity==claimed['best_returned_id']
    assert score==values.min(), (family,score,float(values.min()))
    return dict(group=family, model_shape=list(q.shape), candidates=len(values), legal=len(found),
                samples=len(returned), attempts_with_optimum=len(hits), minimum_legal=0,
                minimum_illegal=2, signed_energy_difference_max=float(np.max(abs(energy_q-energy_i))),
                h_max=102,J_max=1,best=score,id=identity,material=material)

def verify(run):
    summary=read_json(run/'summary.json')
    spec=read_json(FROZEN/'manifest.json')
    results={}
    for p,pool,families in [('q2','07',('NO2',)),('q3','08',('O3','NO2','FO2'))]:
        result=summary['results'][p]
        input_info=result['intake']
        pred=run/input_info['prediction_file']
        official=run/input_info['official_file']
        assert digest(pred)==input_info['prediction_sha256']==spec['outputs'][pool]['sha256']
        assert digest(official)==input_info['official_sha256']==spec['inputs'][pool]['sha256']
        by_id={int(r['id']):r for r in records(pred)}
        assert len(result['models'])==len(families)
        results[p]=[verify_model(run,m,by_id,family,summary['args']['seeds'])
                    for family,m in zip(families,result['models'],strict=True)]
        print(p,[(x['group'],x['legal'],x['samples'],x['attempts_with_optimum']) for x in results[p]])
    winner=min(results['q3'],key=lambda r:r['best'])
    declared=summary['results']['q3']['winner']
    assert (declared['status'],declared['material'],declared['V_hat'],declared['candidate_id'])==(
        'ok',winner['material'],winner['best'],winner['id'])
    data={'run_id':summary['run_id'],'backend':summary['backend'],
          'samples_verified':sum(x['samples'] for items in results.values() for x in items),
          'q3_winner':declared,'results':results}
    (run/'verification.json').write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('run',type=Path)
    verify(ap.parse_args().run.resolve())

