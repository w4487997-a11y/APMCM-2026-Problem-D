"""Regenerate v1 prediction verification, run Kaiwu, and audit the run."""
import argparse
from datetime import datetime, timezone
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]

def run(python, *args):
    subprocess.run([python, '-B', *args], cwd=ROOT, check=True)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--q1-python',default=sys.executable,help='Python with the frozen Q1 requirements')
    parser.add_argument('--sdk-python',default=sys.executable,help='Python with authorized Kaiwu SDK')
    parser.add_argument('--tag',default=None)
    args=parser.parse_args()
    tag=args.tag or datetime.now(timezone.utc).strftime('sdk_%Y%m%dT%H%M%S%fZ')
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',tag):
        parser.error('tag must contain 1–64 ASCII letters, digits, underscores or hyphens')
    if (ROOT/'q23/runs'/tag).exists():
        parser.error(f'run {tag} already exists')
    q1_output=ROOT/'evidence'/f'q1_{tag}'
    run(args.q1_python,'scripts/verify_frozen_q1.py','--out',str(q1_output))
    run(args.sdk_python,'q23/scripts/stage7_entry.py','--problem','all','--backend','sdk','--tag',tag)
    run(args.sdk_python,'scripts/verify_q23_run.py',str(ROOT/'q23/runs'/tag))
    print(f'Frozen Q1 verification: {q1_output}')
    print(f'Q2/Q3 run: {ROOT / "q23/runs" / tag}')

if __name__=='__main__':
    main()

