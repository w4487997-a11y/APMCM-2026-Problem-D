"""Verify and reproduce the frozen v1 models' V1.2 handoff without fitting."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
from importlib.metadata import version
import json
import math
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
OFFICIAL = ROOT / '2026 APMCM Problem D/date'
V1 = ROOT / 'handoff/v1'
HANDOFF = ROOT / 'handoff/v1_2'
COMPOSITION = ('id', 'formula', 'A', 'B', 'X', 'a_eq_b')
POOLS = ('04','07','08','11','12')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def checked_hash(path, expected):
    actual = digest(path)
    if actual != expected:
        raise ValueError(f'Frozen file differs from the manifest: {path}')
    return actual

def rows(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))

def verify(out):
    spec = json.loads((HANDOFF/'manifest.json').read_text(encoding='utf-8'))
    assert spec['frozen_model_release']=='v1'
    checked_hash(V1/'manifest.json',spec['frozen_manifest_sha256'])
    for relative,expected in spec['models'].items():
        checked_hash(V1/relative,expected)
    for inputs in spec['inputs'].values():
        checked_hash(OFFICIAL/inputs['file'],inputs['sha256'])
    checked_hash(HANDOFF/spec['combined_output']['file'],spec['combined_output']['sha256'])
    report={
        'handoff_version':spec['handoff_version'], 'model_release':spec['frozen_model_release'],
        'models_sha256':spec['models'], 'environment':{
            'python':sys.version.split()[0], **{n:version(n) for n in (
                'numpy','scipy','scikit-learn','joblib','threadpoolctl')}},
        'pools':{},
    }
    out.mkdir(parents=True, exist_ok=False)
    for pool in POOLS:
        child=spec['outputs'][pool]
        archived=HANDOFF/child['file']
        old=V1/child['frozen_file']
        checked_hash(archived,child['sha256'])
        checked_hash(old,child['frozen_sha256'])
        pool_spec=spec['inputs'][pool]
        source=OFFICIAL/pool_spec['file']
        model_file='q1_final.joblib' if pool=='04' else 'q23_final.joblib'
        model_version=('q1' if pool=='04' else 'q23')+'_final_v1_hgb_gap_mix'
        prediction=out/archived.name
        subprocess.run([sys.executable,'-B','-m','q1.predict','--model',str(V1/'models'/model_file),
                        '--input',str(source),'--output',str(prediction),'--source-pool',pool],
                       cwd=ROOT,check=True)
        current, frozen, earlier, official=(rows(p) for p in (prediction,archived,old,source))
        assert len(current)==len(frozen)==len(earlier)==len(official)==child['rows']
        deltas=[]
        for live, reference, original, raw in zip(current,frozen,earlier,official,strict=True):
            assert all(live[field]==reference[field]==original[field]==raw[field] for field in COMPOSITION)
            assert live['source_pool']==reference['pool']==reference['source_pool']==pool
            assert live['model_version']==reference['model_version']==model_version
            assert reference['V_hat']==original['V_hat']
            value=float(live['V_hat'])
            assert math.isfinite(value)
            deltas.append(abs(value-float(reference['V_hat'])))
        max_delta=max(deltas)
        assert max_delta<1e-10, (pool,max_delta)
        report['pools'][pool]=dict(rows=len(current), model_version=model_version,
                                   training_splits=spec['model_training'][model_version]['train_splits'],
                                   max_abs_difference=max_delta, frozen_prediction_sha256=child['sha256'],
                                   frozen_file=archived.relative_to(ROOT).as_posix())
        print(f'{pool}  {len(current)} rows  maximum frozen-score delta = {max_delta:.3g}',flush=True)
    (out/'verification.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path,default=None)
    args=ap.parse_args()
    name=datetime.now(timezone.utc).strftime('q1_verified_%Y%m%dT%H%M%S%fZ')
    verify((args.out or ROOT/'evidence'/name).resolve())

if __name__=='__main__':
    main()

