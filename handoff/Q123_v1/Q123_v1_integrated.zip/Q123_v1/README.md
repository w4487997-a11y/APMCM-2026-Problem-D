# APMCM 2026 D 题 Q1–Q3 整合技术交付

本交付冻结原版 **hgb_gap_mix v1**，使用 **V1.2** 预测接口。Q1 官方 04 池预测与 Q2/Q3 的输入分别来自原先 02 拟合版和 02+03 重训版。Q2/Q3 已从冻结输入重跑 Kaiwu SDK 的 8 位适配与本地求解，矩阵、样本、输入及汇总按运行目录保存。

| 用途 | 入口 |
| --- | --- |
| Q1 官方 04 池 3,703 条预测，含原始标识和 V̂ | [q1_holdout_predictions.csv](handoff/v1_2/q1_holdout_predictions.csv) |
| Q1 原版两套权重、接口版本、池和文件哈希 | [Q1 权重清单](handoff/v1_2/manifest.json) |
| Q2/Q3 正式 SDK 结果与原始文件指纹 | [SDK 汇总](q23/runs/sdk_v1_frozen_30x10/summary.json) · [独立核验](q23/runs/sdk_v1_frozen_30x10/verification.json) |
| 本地退火对照 | [对照汇总](q23/runs/local_v1_frozen_30x10/summary.json) |
| 论文数据、图和口径 | [论文证据](paper/PAPER_EVIDENCE.md) |
| 版本、运行记录及验收 | [整合记录](evidence/INTEGRATION_RECORD.md) |

## 一键复现

在本目录运行，分别指向已经安装依赖的 Python 和已有授权的 Kaiwu Python。两个环境都已具备依赖时可以指向同一个解释器。本次 Q1 用 Python 3.10.11 及 [requirements-baseline.txt](requirements-baseline.txt) 的固定版本，Q2/Q3 用 Python 3.10.11、NumPy 2.2.6、Kaiwu 1.4.3。

~~~powershell
python -B scripts/run_all.py --q1-python "<Q1 Python 路径>" --sdk-python "<Kaiwu Python 路径>" --tag replay_v1
~~~

命令逐池重新推理并核对原版 Q1，使用已锁定的 07/08 预测建模、8 位适配和求解，再独立解码与复算。运行目录为 `q23/runs/replay_v1/`。重复标签会被拒绝，换标签即可重跑。未完成求解时该目录可能留有部分产物，完整汇总写在 `summary.json`。单独运行 SDK 的入口见 [整合记录](evidence/INTEGRATION_RECORD.md)。

## 交付范围

04 预测按原始标识和行序保留，共 3,703 条。论文可采用随包表图和实际 SDK 结果，当前结果属于 CPU 本地求解。历史平台设备运行的证据另有原交付记录，新整合路径未新增设备任务。正式赛题英文稿、赛务表格、AI 使用说明以及平台上传格式由提交侧确认和汇总。
