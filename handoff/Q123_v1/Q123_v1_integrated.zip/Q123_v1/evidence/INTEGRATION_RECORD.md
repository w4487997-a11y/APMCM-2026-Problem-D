# Q1–Q3 整合记录

## 版本与决定

以 Git 提交 b5f6138762f7c109e3ee24b4fd327bbe4dafcb1b 中的 Q1 原版工程和 V1.2 接口为基线。按用户决定冻结 hgb_gap_mix v1。保留 02 权重、02+03 权重、旧版候选分数、实验数据、依赖和数据契约。Q2/Q3 取提交 7c725738e73b2a63b3317732f5cbc2b216c58101 的 stage7 正式入口和已验收的 104 位整数分区，整合层更新默认预测位置及运行归档。Q1 推理复核和 QUBO 审计均未重新拟合。 [Q1 提交](https://github.com/w4487997-a11y/APMCM-2026-Problem-D/commit/b5f6138762f7c109e3ee24b4fd327bbe4dafcb1b) · [Q23 提交](https://github.com/w4487997-a11y/APMCM-2026-Problem-D/commit/7c725738e73b2a63b3317732f5cbc2b216c58101)

核心变更为每次运行生成独立目录，永久保留正式输入快照、所用矩阵、原始样本、汇总及逐文件哈希。已存在标签会退出。样本记录明确的候选 ID 和实际 SDK 种子，运行记录包含参数、环境、输入和模型哈希。保留自写退火的原逻辑，在结果 metadata 中标明尝试分组口径。

## 实际执行与验收

| 项目 | 执行与结论 |
| --- | --- |
| Q1 推理 | 使用原版锁定依赖，对 04/07/08/11/12 共 16,635 条池记录重新推理。身份和原始行序一致，五池最大绝对分差均为 0。 |
| Q1 单元测试 | 原工程 14/14 通过。 |
| Q23 入口 | Q2 和 Q3 各 13/13 类错误输入被拒绝。重复运行标签测试被拒绝，已有结果保留。低预算 Q3 三组均无合法样本时明确输出 solver_failed。 |
| SDK 正式实验 | CPU 本地 8 位适配，固定 30 个种子，每个取样 10 条，iters=300、alpha=0.99。四张 104 位矩阵全部合法，每组 300 条原始样本。 |
| 自写退火对照 | 按原实现运行同一矩阵和参数，每个模型 300 条链，分成 30 组。作为本地算法对照。 |
| 独立验证 | 对 SDK 及自写退火的 2,400 条原始样本逐条解码，复算量化哈密顿量，核验所有候选、完整能量和归档哈希。 |
| 一键复现 | 把工程复制到不同目录，从根入口使用两套解释器顺序完成五池推理、SDK 求解和样本复算。 |

[冻结推理](q1_verified/verification.json) · [Q1 单元测试](q1_unittest.log) · [Q23 输入负例](../q23/results/stage8_negative_validation.json) · [重复标签日志](q23_duplicate_tag.log) · [低预算日志](q23_no_legal.log) · [SDK 重跑日志](sdk_v1_frozen_30x10.log) · [退火对照日志](local_v1_frozen_30x10.log) · [换目录复跑日志](relocated_run_all.log)

## 分阶段复现

~~~powershell
python -B scripts/verify_frozen_q1.py
python -B -m unittest discover -s tests
python -B q23/scripts/stage7_entry.py --problem all --backend sdk --tag sdk_new_run
python -B scripts/verify_q23_run.py q23/runs/sdk_new_run
~~~

前两条使用 Q1 固定依赖环境。后两条使用已授权 Kaiwu 1.4.3 的 Python。`scripts/run_all.py` 可以接受两个解释器路径并顺序运行正式 Q1 核验和 SDK 复算。本报告记录所有新实验的计算均为本地完成，无新 SPQC 调用。
