﻿# -*- coding: utf-8 -*-
"""生成平台可接受的整数矩阵（8 位 INT，范围 [-128, 127]）。

平台会拒绝浮点或超范围系数，报错形如：
    数据精度超过 8bit-INT 空间 [-128, 127]

做法：整张矩阵乘一个整数比例 s = floor(127 / max|Q|) 后四舍五入。
s 的选择保证 max|Q|·s ≤ 127，同时罚项仍是整数、代价占满剩余格点。
"""

import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
MAT = os.path.join(HERE, "matrices")
UP = os.path.join(HERE, "platform_upload")
RES = os.path.join(HERE, "results")

SPECS = [
    ("q2_full", "qubo_q2_official_v12.npz", "qubo_q2.csv", "q2"),
    ("q2_clip", "qubo_q2_official_v12_8bit.npz", "qubo_q2_8bit.csv", "q2"),
    ("q3_clip", "qubo_q3_official_v12_8bit.npz", "qubo_q3_8bit.csv", "q3"),
]


def main():
    os.makedirs(UP, exist_ok=True)
    os.makedirs(RES, exist_ok=True)
    summary = []
    for tag, npz_name, csv_name, problem in SPECS:
        path = os.path.join(MAT, npz_name)
        if not os.path.exists(path):
            print(f"跳过 {tag}：缺 {npz_name}")
            continue
        z = np.load(path, allow_pickle=True)
        Q = z["Q"].astype(float)
        const = float(z["constant"])
        raw = z["raw_scores"].astype(float)

        s = int(np.floor(127.0 / float(np.abs(Q).max())))
        Qi = np.rint(Q * s).astype(np.int64)
        if Qi.max() > 127 or Qi.min() < -128:
            raise SystemExit(f"{tag}: 整数化后越界 [{Qi.min()}, {Qi.max()}]")
        const_i = int(round(const * s))

        names = [str(x) for x in z["var_names"]]
        A = z["candidate_A"].astype(str)
        B = z["candidate_B"].astype(str)
        X = z["candidate_X"].astype(str) if "candidate_X" in z.files else None
        elems = sorted(set(A) | set(B))

        # 用整数矩阵重新枚举，确认最优是否保持
        ia = {e: i for i, e in enumerate(elems)}
        if problem == "q2":
            idx = np.array([(ia[a], 52 + ia[b]) for a, b in zip(A, B)])
            n_u = None
        else:
            xs = sorted(set(X))
            ix = {x: k for k, x in enumerate(xs)}
            idx = np.array([(ia[a] * len(xs) + ix[x], 156 + ia[b])
                            for a, b, x in zip(A, B, X)])
            n_u = 156

        e = const_i + Qi[idx[:, 0], idx[:, 0]] + Qi[idx[:, 1], idx[:, 1]] \
            + Qi[np.minimum(idx[:, 0], idx[:, 1]), np.maximum(idx[:, 0], idx[:, 1])]
        o_int = np.argsort(e, kind="stable")
        o_raw = np.argsort(raw, kind="stable")
        material_int = (A[o_int[0]], B[o_int[0]]) if problem == "q2" else (A[o_int[0]], B[o_int[0]], X[o_int[0]])
        material_raw = (A[o_raw[0]], B[o_raw[0]]) if problem == "q2" else (A[o_raw[0]], B[o_raw[0]], X[o_raw[0]])

        np.savetxt(os.path.join(UP, csv_name), Qi, delimiter=",", fmt="%d")
        meta = {
            "problem": problem, "tag": tag,
            "variables": int(Qi.shape[0]), "scale": s,
            "constant_integer": const_i,
            "constant_float": const,
            "convention": "H = xᵀQx + constant；上三角；坐标从 0 开始；系数为 8 位整数",
            "variable_names": names,
            "source_npz": npz_name,
            "matrix_abs_max_int": int(np.abs(Qi).max()),
            "cost_levels": int(np.abs(Qi).max() - 1),
            "integer_argmin": list(material_int),
            "raw_argmin": list(material_raw),
            "argmin_preserved": bool(tuple(material_int) == tuple(material_raw)),
            "ties_at_minimum_integer": int(np.sum(e == e[o_int[0]])),
            "oracle_raw_score": float(raw[o_raw[0]]),
        }
        with open(os.path.join(UP, csv_name.replace(".csv", "_meta.json")), "w",
                  encoding="utf-8") as fh:
            json.dump(meta, fh, ensure_ascii=False, indent=2)

        print(f"{tag:9s} s={s:<3d} 系数 ∈ [{Qi.min():4d}, {Qi.max():4d}] "
              f"常数 {const_i:<4d} 最优保持={meta['argmin_preserved']} "
              f"并列={meta['ties_at_minimum_integer']} 材料={material_int}")
        summary.append(meta)

    with open(os.path.join(RES, "platform_int_matrices.json"), "w", encoding="utf-8") as fh:
        json.dump(summary, fh, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
