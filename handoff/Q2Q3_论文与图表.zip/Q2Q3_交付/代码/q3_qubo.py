# -*- coding: utf-8 -*-
"""问题三：X ∈ {O3, NO2, FO2} 三选一 + A、B 各选一个，使 V̂ 最小。

编码：A 与 X 合并成联合状态 u_(i,k)（52×3 = 156 个比特），加 B 位 52 个，共 208 比特。
      这样目标天然是二次型，不需要辅助比特降阶。

用法：
    python q3_qubo.py --pred q2_project/data_official/q3_pool_predictions.csv --tag official_v12
"""

import argparse
import json
import os

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
OUT = os.path.join(HERE, "matrices")
LAM = 2.0
SEED = 42


def build_q3(costs, elems_a, xs, elems_b, lam=LAM):
    """costs[(a,b,x)] = c；返回上三角 Q 与常数项。索引：u = i*|X| + k，b = n_u + j。"""
    nA, nX, nB = len(elems_a), len(xs), len(elems_b)
    n_u = nA * nX
    n = n_u + nB
    Q = np.zeros((n, n))
    for t in range(n_u):
        Q[t, t] -= lam
    for j in range(nB):
        Q[n_u + j, n_u + j] -= lam
    for i in range(n_u):
        for j in range(i + 1, n_u):
            Q[i, j] += 2 * lam
    for i in range(nB):
        for j in range(i + 1, nB):
            Q[n_u + i, n_u + j] += 2 * lam
    const = 2 * lam
    ia = {a: i for i, a in enumerate(elems_a)}
    ib = {b: j for j, b in enumerate(elems_b)}
    ix = {x: k for k, x in enumerate(xs)}
    for (a, b, x), c in costs.items():
        Q[ia[a] * nX + ix[x], n_u + ib[b]] += c
    return Q, const


def energy(Q, const, u_idx, b_idx):
    return const + Q[u_idx, u_idx] + Q[b_idx, b_idx] + Q[u_idx, b_idx]


def anneal_pairs(Q, const, nA, nX, nB, iters=200000, seed=SEED, t0=0.5, t1=0.002):
    rng = np.random.default_rng(seed)
    n_u = nA * nX
    i, k, j = (int(rng.integers(0, nA)), int(rng.integers(0, nX)),
               int(rng.integers(0, nB)))
    e = energy(Q, const, i * nX + k, n_u + j)
    best, best_state = e, (i, k, j)
    for t in range(iters):
        T = t0 * (t1 / t0) ** (t / iters)
        which = int(rng.integers(0, 3))
        if which == 0:
            ni, nk, nj = int(rng.integers(0, nA)), k, j
        elif which == 1:
            ni, nk, nj = i, int(rng.integers(0, nX)), j
        else:
            ni, nk, nj = i, k, int(rng.integers(0, nB))
        ne = energy(Q, const, ni * nX + nk, n_u + nj)
        if ne <= e or rng.random() < np.exp((e - ne) / T):
            i, k, j, e = ni, nk, nj, ne
            if e < best - 1e-12:
                best, best_state = e, (i, k, j)
    return best, best_state


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pred", required=True)
    ap.add_argument("--tag", default="official")
    args = ap.parse_args()
    os.makedirs(OUT, exist_ok=True)

    pool = pd.read_csv(args.pred, encoding="utf-8-sig")
    pool["id"] = pool["id"].astype(int)
    xs = sorted(pool["X"].unique())
    elems = sorted(set(pool["A"]) | set(pool["B"]))
    assert len(elems) == 52 and xs == ["FO2", "NO2", "O3"], (len(elems), xs)
    assert len(pool) == 8112, len(pool)

    raw = pool["V_hat"].to_numpy(float)
    lo, hi = float(raw.min()), float(raw.max())
    scaled = (raw - lo) / (hi - lo)

    costs = {(a, b, x): float(c) for (a, b, x), c in
             zip(pool[["A", "B", "X"]].itertuples(index=False, name=None), scaled)}
    Q, const = build_q3(costs, elems, xs, elems)

    ia = {a: i for i, a in enumerate(elems)}
    ix = {x: k for k, x in enumerate(xs)}
    n_u = 52 * len(xs)

    max_err, best_e, best_key = 0.0, np.inf, None
    for (a, b, x), c in costs.items():
        e = energy(Q, const, ia[a] * len(xs) + ix[x], n_u + ia[b])
        max_err = max(max_err, abs(e - c))
        if e < best_e:
            best_e, best_key = e, (a, b, x)

    k_star = min(costs, key=costs.get)
    assert k_star == best_key, (k_star, best_key)
    star = pool[(pool.A == k_star[0]) & (pool.B == k_star[1]) & (pool.X == k_star[2])].iloc[0]

    rng = np.random.default_rng(SEED)
    illegal_min = np.inf
    for _ in range(20000):
        if rng.random() < 0.5:                       # 两个 u
            i1, i2 = rng.choice(n_u, 2, replace=False)
            bits = (int(i1), int(i2))
            illegal_min = min(illegal_min, const + Q[bits[0], bits[0]] + Q[bits[1], bits[1]]
                              + Q[min(bits), max(bits)])
        else:                                        # 两个 b
            j1, j2 = rng.choice(52, 2, replace=False)
            i1 = n_u + int(j1)
            i2 = n_u + int(j2)
            illegal_min = min(illegal_min, const + Q[i1, i1] + Q[i2, i2]
                              + Q[min(i1, i2), max(i1, i2)])

    sa_e, sa_state = anneal_pairs(Q, const, 52, len(xs), 52)
    sa_key = (elems[sa_state[0]], elems[sa_state[2]], xs[sa_state[1]])
    sa_ok = abs(sa_e - best_e) < 1e-9 and sa_key == k_star

    order = np.argsort(scaled)
    top10 = [{"A": pool.iloc[i]["A"], "B": pool.iloc[i]["B"], "X": pool.iloc[i]["X"],
              "V_hat": float(raw[i]), "scaled": float(scaled[i])} for i in order[:10]]

    report = {
        "problem": "Q3 (X ∈ {O3, NO2, FO2})",
        "candidates": int(len(pool)), "variables": int(Q.shape[0]),
        "encoding": "joint state u_(A,X) 156 + B 52 = 208",
        "lambda": LAM, "scaling": {"lo": lo, "hi": hi},
        "max_energy_vs_cost": float(max_err),
        "oracle": {"A": k_star[0], "B": k_star[1], "X": k_star[2],
                   "V_hat": float(star["V_hat"]), "scaled_cost": float(costs[k_star]),
                   "energy": float(best_e)},
        "first_to_second_gap_scaled": float(np.sort(scaled)[1] - np.sort(scaled)[0]),
        "first_to_second_gap_raw": float(np.sort(raw)[1] - np.sort(raw)[0]),
        "illegal_sample_min_energy": float(illegal_min),
        "sa": {"energy": float(sa_e), "material": list(sa_key), "ok": bool(sa_ok)},
        "matrix": {"nnz": int(np.count_nonzero(Q)),
                   "abs_min": float(np.abs(Q[Q != 0]).min()),
                   "abs_max": float(np.abs(Q).max())},
        "top10": top10,
    }
    with open(os.path.join(RES, f"q3_result_{args.tag}.json"), "w", encoding="utf-8") as fh:
        json.dump(report, fh, ensure_ascii=False, indent=2)

    np.savez_compressed(
        os.path.join(OUT, f"qubo_q3_{args.tag}.npz"),
        Q=Q, constant=np.array(const),
        convention=np.array("H(x)=x^T Q x + constant; Q 上三角；x∈{0,1}^208，"
                            "前 156 位为 u_(A,X)（i*3+k），后 52 位为 B"),
        var_names=np.array([f"u:{a}|{x}" for a in elems for x in xs] + [f"b:{b}" for b in elems]),
        candidate_A=pool["A"].to_numpy(), candidate_B=pool["B"].to_numpy(),
        candidate_X=pool["X"].to_numpy(), candidate_id=pool["id"].to_numpy(),
        raw_scores=raw, scaled_scores=scaled,
        scaling=np.array([lo, hi]), penalty=np.array([LAM, LAM]),
        oracle_material=np.array([json.dumps(list(k_star))]),
        oracle_score=np.array([costs[k_star]]),
        oracle_raw_score=np.array([float(star["V_hat"])]),
        meta=np.array([json.dumps(report, ensure_ascii=False)]),
    )

    print(f"候选 {len(pool):,}｜变量 {Q.shape[0]}｜max|E−cost| = {max_err:.1e}")
    print(f"最优：A={k_star[0]}, B={k_star[1]}, X={k_star[2]}｜"
          f"V_hat={star['V_hat']:.5f}｜能量={best_e:.6f}")
    print(f"首位间隔：原始 {report['first_to_second_gap_raw']:.5f}｜"
          f"缩放后 {report['first_to_second_gap_scaled']:.6f}")
    print(f"非法抽样最小能量 = {illegal_min:.4f}（应 > {max(costs.values()):.4f}）")
    print(f"模拟退火：能量={sa_e:.6f}，解={sa_key}，一致={sa_ok}")
    print(f"已写：results/q3_result_{args.tag}.json、matrices/qubo_q3_{args.tag}.npz")


if __name__ == "__main__":
    main()
