﻿# -*- coding: utf-8 -*-
"""按「Ising 系数必须是整数」的假设构造矩阵。

若平台把 Ising 系数存成 8 位整数，那么带分数（0.25、0.5）的系数会迫使整体乘 4 才能整数化，
h 随之放大 4 倍而超限。做法：
  - 2λ 取 4 的倍数（λ 为偶数）→ J = 2λ/4 = λ/2 是整数；
  - 代价取 4 的倍数 → 代价项 /4 是整数；
  - q_ii = −λ 为偶数 → q_ii/2 是整数。
于是 h 与 J 全部为整数，无需再缩放。
"""

import json
import os

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
PRED = os.path.join(HERE, "data_official", "q2_pool_predictions.csv")
UP = os.path.join(HERE, "platform_upload")
MAT = os.path.join(HERE, "matrices")
RES = os.path.join(HERE, "results")
CAP = 1.0
LIMIT = 127


def ising(Q):
    S = Q + Q.T
    np.fill_diagonal(S, 0)
    h = np.diag(Q) / 2.0 + S.sum(axis=1) / 4.0
    J = np.triu(Q, k=1) / 4.0
    return h, J


def build(pool, n_top, lam, cap=CAP):
    sub = pool.nsmallest(n_top, "V_hat")
    A, B = sorted(set(sub["A"])), sorted(set(sub["B"]))
    grid = pool[pool["A"].isin(A) & pool["B"].isin(B)][["A", "B", "V_hat", "id"]].copy()
    ia = {e: i for i, e in enumerate(A)}
    ib = {e: i for i, e in enumerate(B)}
    nA, nB = len(A), len(B)
    n = nA + nB

    raw = grid["V_hat"].to_numpy(float)
    lo = float(raw.min())
    levels = lam // 4                       # 代价可用的 4 的倍数档位（不含 0）
    clipped = np.minimum(raw, lo + cap)
    cost = np.round((clipped - lo) / cap * levels).astype(int) * 4
    cost = np.clip(cost, 0, 4 * levels)

    Q = np.zeros((n, n), dtype=np.int64)
    Q[np.arange(nA), np.arange(nA)] = -lam
    Q[nA + np.arange(nB), nA + np.arange(nB)] = -lam
    for i in range(nA):
        for j in range(i + 1, nA):
            Q[i, j] = 2 * lam
    for i in range(nB):
        for j in range(i + 1, nB):
            Q[nA + i, nA + j] = 2 * lam
    for (a, b), c in zip(grid[["A", "B"]].itertuples(index=False, name=None), cost):
        Q[ia[a], nA + ib[b]] += int(c)

    idx = np.array([(ia[a], nA + ib[b])
                    for a, b in grid[["A", "B"]].itertuples(index=False, name=None)])
    e = Q[idx[:, 0], idx[:, 0]] + Q[idx[:, 1], idx[:, 1]] + Q[idx[:, 0], idx[:, 1]]
    o = int(np.argmin(e))
    material = (grid.iloc[o]["A"], grid.iloc[o]["B"])
    true_best = (grid.iloc[int(np.argmin(raw))]["A"], grid.iloc[int(np.argmin(raw))]["B"])
    return dict(Q=Q, A=A, B=B, grid=grid, lam=lam, levels=levels,
                material=material, true_best=true_best, ok=material == true_best,
                ties=int(np.sum(e == e[o])), lo=lo, lsb=cap / levels)


def main():
    pool = pd.read_csv(PRED, encoding="utf-8-sig")
    rows, best = [], None
    for n_top in (10, 15, 20, 25, 29):
        for lam in (12, 16, 20, 24, 28, 32, 36):
            if lam % 2:
                continue
            r = build(pool, n_top, lam)
            h, J = ising(r["Q"])
            int_ok = bool(np.allclose(h, np.round(h)) and np.allclose(J, np.round(J)))
            mh, mJ = float(np.abs(h).max()), float(np.abs(J).max())
            r.update(max_h=mh, max_J=mJ, integer_ising=int_ok, n_top=n_top)
            rows.append(r)
            if r["ok"] and int_ok and mh <= LIMIT:
                if best is None or (n_top, lam) > (best["n_top"], best["lam"]):
                    best = dict(r)

    print(f"{'top':>4} {'λ':>3} {'宽度':>7} {'变量':>4} {'|h|':>6} {'|J|':>4} "
          f"{'Ising整数':>9} {'LSB':>7} 解 ok")
    for r in sorted(rows, key=lambda x: (not x["integer_ising"], -x["n_top"], x["max_h"]))[:10]:
        print(f"{r['n_top']:>4} {r['lam']:>3} {len(r['A']):>3}×{len(r['B']):<3} "
              f"{r['Q'].shape[0]:>4} {r['max_h']:>6.1f} {r['max_J']:>4.1f} "
              f"{str(r['integer_ising']):>9} {r['lsb']:>7.4f} "
              f"{'-'.join(r['material'])} {r['ok']}")

    if best is None:
        print("没有同时满足整数 Ising 与范围限制的组合")
        return

    Q, lam = best["Q"], best["lam"]
    print(f"\n采用 top{best['n_top']}、λ={lam}：{Q.shape[0]} 变量，"
          f"{len(best['A'])}×{len(best['B'])}={len(best['grid'])} 候选，"
          f"|h|={best['max_h']:.0f}、|J|={best['max_J']:.0f}（均为整数），LSB={best['lsb']:.4f}")
    np.savetxt(os.path.join(UP, "qubo_q2_intising.csv"), Q, delimiter=",", fmt="%d")
    np.savez_compressed(
        os.path.join(MAT, "qubo_q2_intising.npz"),
        Q=Q.astype(float), constant=np.array(2 * lam),
        var_names=np.array([f"a:{e}" for e in best["A"]] + [f"b:{e}" for e in best["B"]]),
        candidate_A=best["grid"]["A"].to_numpy(), candidate_B=best["grid"]["B"].to_numpy(),
        candidate_id=best["grid"]["id"].to_numpy(),
        raw_scores=best["grid"]["V_hat"].to_numpy(float),
        oracle_material=np.array([json.dumps(list(best["true_best"]))]),
        oracle_raw_score=np.array([float(best["grid"]["V_hat"].min())]),
        elements_A=np.array(best["A"]), elements_B=np.array(best["B"]),
    )
    meta = {
        "problem": "q2", "tag": "intising", "source_npz": "qubo_q2_intising.npz",
        "variables": int(Q.shape[0]), "scale": 1, "constant_integer": 2 * lam,
        "convention": "H=xᵀQx+constant；上三角；整数；2λ 与代价均为 4 的倍数，使 Ising 系数为整数",
        "elements_A": best["A"], "elements_B": best["B"],
        "variable_names": [f"a:{e}" for e in best["A"]] + [f"b:{e}" for e in best["B"]],
        "n_candidates": int(len(best["grid"])),
        "lambda": lam, "cost_bins": best["levels"],
        "cost_lsb_raw": round(best["lsb"], 5),
        "max_abs_ising_h": round(best["max_h"], 3),
        "max_abs_ising_J": round(best["max_J"], 3),
        "integer_ising": True,
        "raw_argmin": list(best["true_best"]),
        "notes": "短名单 + Ising 整数化；矩阵覆盖 |A|×|B| 全部组合",
    }
    with open(os.path.join(UP, "qubo_q2_intising_meta.json"), "w", encoding="utf-8") as fh:
        json.dump(meta, fh, ensure_ascii=False, indent=2)
    with open(os.path.join(RES, "q2_intising_scan.json"), "w", encoding="utf-8") as fh:
        json.dump([{k: v for k, v in r.items() if k not in ("Q", "grid")} for r in rows],
                  fh, ensure_ascii=False, indent=2)
    print("已写 platform_upload/qubo_q2_intising.csv 与 _meta.json")


if __name__ == "__main__":
    main()
