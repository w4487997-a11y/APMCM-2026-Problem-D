﻿# -*- coding: utf-8 -*-
"""生成论文用图：问题二前十、问题三按 X 分布、真机采样能量、量化前后对照。

输出：q2_project/figures/*.png（300 dpi）
运行：venv-mirna/Scripts/python.exe make_figures.py
"""

import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import font_manager

HERE = os.path.dirname(os.path.abspath(__file__))
FIG = os.path.join(HERE, "figures")
os.makedirs(FIG, exist_ok=True)

for name in ("msyh.ttc", "simhei.ttf"):
    p = os.path.join(r"C:\Windows\Fonts", name)
    if os.path.exists(p):
        font_manager.fontManager.addfont(p)
plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 120
plt.rcParams["savefig.dpi"] = 300

NAVY = "#1F3864"
ACCENT = "#C00000"
GREY = "#8C8C8C"


def fig1_q2_top10():
    pool = pd.read_csv(os.path.join(HERE, "data_official", "q2_pool_predictions.csv"),
                       encoding="utf-8-sig").nsmallest(10, "V_hat")
    labels = [f"{a}–{b}" for a, b in zip(pool["A"], pool["B"])][::-1]
    vals = pool["V_hat"].to_numpy()[::-1]
    colors = [ACCENT if i == len(vals) - 1 else NAVY for i in range(len(vals))]
    fig, ax = plt.subplots(figsize=(6.4, 4.2))
    bars = ax.barh(labels, vals, color=colors, height=0.62)
    for b, v in zip(bars, vals):
        ax.text(v + 0.04, b.get_y() + b.get_height() / 2, f"{v:.3f}",
                va="center", fontsize=9, color="#333333")
    ax.set_xlabel("代理违反度 $\\hat{V}$")
    ax.set_xlim(0, max(vals) * 1.18)
    ax.set_title("问题二：07 池前十名（红为最优）", fontsize=11)
    ax.grid(axis="x", alpha=0.25, linestyle="--")
    ax.set_axisbelow(True)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig1_q2_top10.png"), bbox_inches="tight")
    plt.close(fig)


def fig2_q3_by_x():
    pool = pd.read_csv(os.path.join(HERE, "data_official", "q3_pool_predictions.csv"),
                       encoding="utf-8-sig")
    order = ["O3", "NO2", "FO2"]
    data = [pool.loc[pool["X"] == x, "V_hat"].to_numpy() for x in order]
    fig, ax = plt.subplots(figsize=(6.4, 4.2))
    bp = ax.boxplot(data, tick_labels=order, patch_artist=True, widths=0.5,
                    flierprops=dict(marker="o", markersize=2, alpha=0.25,
                                    markerfacecolor=GREY, markeredgecolor="none"))
    for patch, c in zip(bp["boxes"], ["#2E5C9A", "#7F9AC4", "#B9C7DD"]):
        patch.set_facecolor(c)
        patch.set_alpha(0.85)
    for i, d in enumerate(data, start=1):
        ax.scatter([i], [d.min()], color=ACCENT, zorder=5, s=28)
        ax.annotate(f"min {d.min():.3f}", (i, d.min()), textcoords="offset points",
                    xytext=(8, -10), fontsize=8, color=ACCENT)
    ax.set_yscale("log")
    ax.set_ylabel("代理违反度 $\\hat{V}$（对数轴）")
    ax.set_title("问题三：按 X 族分组的违反度分布", fontsize=11)
    ax.grid(axis="y", alpha=0.25, linestyle="--")
    ax.set_axisbelow(True)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig2_q3_by_x.png"), bbox_inches="tight")
    plt.close(fig)


def fig3_machine_samples():
    log = json.load(open(os.path.join(HERE, "platform_upload", "q2_int_01.log"),
                         encoding="utf-8"))
    vals = [item["quboValue"] for item in log]
    legal = [item["quboValue"] == min(vals) for item in log]
    idx = np.arange(len(vals))
    fig, ax = plt.subplots(figsize=(6.4, 4.0))
    colors = ["#2E7D32" if ok else "#B0B0B0" for ok in legal]
    ax.bar(idx, vals, color=colors)
    ax.set_xticks(idx)
    ax.set_xticklabels([f"#{i}" for i in idx], fontsize=8)
    ax.set_ylabel("平台返回的 QUBO 值")
    ax.set_title("问题二真机任务：10 次采样的能量（绿为合法解）", fontsize=11)
    ax.set_yscale("symlog", linthresh=10)
    ax.set_ylim(-400, 2.5e4)
    for i, val in enumerate(vals):
        ax.annotate(str(int(val)), (i, val), textcoords="offset points",
                    xytext=(0, 8 if val >= 0 else -16), ha="center",
                    fontsize=6.5, color="#333333")
    ax.annotate("Y–Ti（合法最优）", (0, vals[0]), textcoords="offset points",
                xytext=(16, 26), fontsize=8, color="#2E7D32")
    ax.grid(axis="y", alpha=0.25, linestyle="--")
    ax.set_axisbelow(True)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig3_machine_samples.png"), bbox_inches="tight")
    plt.close(fig)


def fig4_quantization():
    """对比两种编码在 8 位下“代价档位”的粗细：档位越少，并列越多。"""
    z = np.load(os.path.join(HERE, "matrices", "qubo_q2_official_v12.npz"), allow_pickle=True)
    A = z["candidate_A"].astype(str)
    B = z["candidate_B"].astype(str)
    raw = z["raw_scores"].astype(float)
    order = np.argsort(raw)[:20]
    v = raw[order]
    lo = float(raw.min())

    def bins(levels, cap):
        clipped = np.minimum(v, lo + cap)
        return np.clip(np.round((clipped - lo) / cap * levels).astype(int), 0, levels)

    full_bins = bins(31, float(raw.max()) - lo)     # 全量：整池跨度、31 个格点
    clip_bins = bins(62, 0.4)                       # 截断：min+0.4、62 个格点

    fig, axes = plt.subplots(1, 2, figsize=(9.6, 4.0))
    for ax, yb, title, color in (
            (axes[0], full_bins, "(a) 全量矩阵 λ=2：代价仅 31 档", "#8C8C8C"),
            (axes[1], clip_bins, "(b) 截断 Δ=0.4、λ=1.02：代价 62 档", NAVY)):
        jitter = np.linspace(-0.02, 0.02, len(v))
        ax.scatter(v, yb + jitter, s=26, color=color)
        ties = int(np.sum(yb == 0))
        ax.axhline(0, color=ACCENT, lw=0.8, ls="--", alpha=0.7)
        ax.set_xlabel("代理违反度 $\\hat{V}$")
        ax.set_ylabel("量化后的代价档位")
        ax.set_title(title, fontsize=10)
        ax.grid(alpha=0.25, linestyle="--")
        ax.set_axisbelow(True)
        ax.annotate(f"最低档并列 {ties} 个", (0.98, 0.06), xycoords="axes fraction",
                    ha="right", fontsize=9, color=ACCENT)
    fig.suptitle("问题二：8 位量化下的代价分辨率（前 20 名）", fontsize=11)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig4_quantization.png"), bbox_inches="tight")
    plt.close(fig)

if __name__ == "__main__":
    fig1_q2_top10()
    fig2_q3_by_x()
    fig3_machine_samples()
    fig4_quantization()
    print("figures written to", FIG)
    for f in sorted(os.listdir(FIG)):
        print("  ", f, os.path.getsize(os.path.join(FIG, f)), "bytes")
