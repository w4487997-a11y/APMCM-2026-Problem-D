﻿# -*- coding: utf-8 -*-
"""把论文草稿 Markdown 转成可编辑的 DOCX（标题/表格/公式/代码块/加粗）。"""

import os
import re
import sys

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, Cm

import build_plan
from build_plan import (
    NAVY, TEXT, WHITE, BODY_CN, HEAD_CN,
    set_run_font, set_col_widths, shade, cell_margins, table_borders,
    row_no_split, para_bottom_border, normalize_xml,
    build_styles, setup_page, build_header_footer, add_table, add_code,
)


def add_inline(p, text):
    """处理 **加粗** 与 `行内代码`。"""
    for part in re.split(r"(\*\*[^*]+\*\*|`[^`]+`)", text):
        if not part:
            continue
        if part.startswith("**") and part.endswith("**"):
            run = p.add_run(part[2:-2])
            set_run_font(run, size=11, bold=True, color=TEXT)
        elif part.startswith("`") and part.endswith("`"):
            run = p.add_run(part[1:-1])
            set_run_font(run, cn="等线", latin="Consolas", size=10, color=TEXT)
        else:
            run = p.add_run(part)
            set_run_font(run, size=11, color=TEXT)


def parse_table(lines, i):
    rows = []
    while i < len(lines) and lines[i].strip().startswith("|"):
        cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
        if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
            rows.append(cells)
        i += 1
    return rows, i


def convert(md_path, out_path):
    lines = open(md_path, encoding="utf-8").read().splitlines()
    doc = Document()
    build_styles(doc)
    setup_page(doc.sections[0])
    build_header_footer(doc.sections[0], "2026 APMCM · D 题 Q2/Q3 论文章节草稿")
    build_plan.TABLE_KEEP_ROWS = 12

    i, n = 0, len(lines)
    first_h1 = True
    while i < n:
        line = lines[i]
        s = line.strip()

        if not s:
            i += 1
            continue

        if s.startswith("```"):
            block, i = [], i + 1
            while i < n and not lines[i].strip().startswith("```"):
                block.append(lines[i])
                i += 1
            add_code(doc, "\n".join(block))
            i += 1
            continue

        if s.startswith("|"):
            rows, i = parse_table(lines, i)
            if rows:
                headers, body = rows[0], rows[1:]
                body = [(r + [""] * (len(headers) - len(r)))[:len(headers)] for r in body]
                widths = [16.0 / len(headers)] * len(headers)
                add_table(doc, {"caption": "", "headers": headers,
                                "rows": body, "widths": widths})
            continue

        if s.startswith("#"):
            level = len(s) - len(s.lstrip("#"))
            text = s[level:].strip()
            if level <= 2:
                p = doc.add_paragraph(style="Heading 2" if level == 2 else "Heading 1")
                if level == 1 and first_h1:
                    p.paragraph_format.page_break_before = False
                    first_h1 = False
                run = p.add_run(text)
                set_run_font(run, cn=HEAD_CN, size=15 if level == 1 else 12.5,
                             bold=True, color=NAVY)
                if level == 1:
                    para_bottom_border(p, color="1F3864", sz=8)
            else:
                p = doc.add_paragraph()
                run = p.add_run(text)
                set_run_font(run, cn=HEAD_CN, size=11, bold=True, color=NAVY)
            i += 1
            continue

        if s.startswith("$$") and s.endswith("$$") and len(s) > 4:
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(s.strip("$").strip())
            set_run_font(run, cn="宋体", latin="Cambria Math", size=11, color=NAVY)
            i += 1
            continue

        if s.startswith(">"):
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.6)
            p.paragraph_format.space_before = Pt(4)
            p.paragraph_format.space_after = Pt(8)
            add_inline(p, s.lstrip("> ").strip())
            i += 1
            continue

        if s.startswith("- "):
            p = doc.add_paragraph()
            pf = p.paragraph_format
            pf.left_indent = Cm(0.9)
            pf.first_line_indent = Cm(-0.45)
            run = p.add_run("▪ ")
            set_run_font(run, size=10, color=NAVY)
            add_inline(p, s[2:].strip())
            i += 1
            continue

        if re.match(r"^\d+\.\s", s):
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.9)
            p.paragraph_format.first_line_indent = Cm(-0.9)
            add_inline(p, s)
            i += 1
            continue

        if s == "---":
            p = doc.add_paragraph()
            p.paragraph_format.space_after = Pt(2)
            para_bottom_border(p, color="D0D7E5", sz=4)
            i += 1
            continue

        p = doc.add_paragraph()
        p.paragraph_format.first_line_indent = Cm(0.75)
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        add_inline(p, s)
        i += 1

    normalize_xml(doc)
    doc.save(out_path)
    print("saved:", out_path)


if __name__ == "__main__":
    convert(sys.argv[1], sys.argv[2])
