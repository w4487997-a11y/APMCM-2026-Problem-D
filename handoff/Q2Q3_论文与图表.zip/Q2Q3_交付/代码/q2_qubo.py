﻿# -*- coding: utf-8 -*-
"""问题二：固定 X = NO2，从 52 种 A、52 种 B 中各选一个，使代理模型预测的 V 最小。

流程：
  1. 读 run_q1.py 产出的 07 池预测（A, B, V_hat）；
  2. 保序缩放到 [0,1]；
  3. 建 104 比特 QUBO（两个独热块 + 交叉代价项 + 非法惩罚）；
  4. 枚举 2,704 个合法候选，逐条核对「矩阵能量 == 缩放代价」；
  5. 抽样非法状态，验证不会被选成最优；
  6. 输出最优材料、QUBO 矩阵与元数据（NPZ）。

运行：python q2_qubo.py
"""

import json
import os
import sys

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
OUT = os.path.join(HERE, "matrices")
LAM = 2.0          # 独热与非法惩罚系数；缩放后代价 ∈ [0,1]
SEED = 42


def build_q2(costs, elems_a, elems_b, lam=LAM):
    """costs[(a,b)] = c；返回上三角 Q 与常数项，H = xᵀQx + const。"""
    nA, nB = len(elems_a), len(elems_b)
    n = nA + nB
    Q = np.zeros((n, n))
    for i in range(nA):
        Q[i, i] -= lam
    for j in range(nB):
        Q[nA + j, nA + j] -= lam
    for i in range(nA):
        for j in range(i + 1, nA):
            Q[i, j] += 2 * lam
    for i in range(nB):
        for j in range(i + 1, nB):
            Q[nA + i, nA + j] += 2 * lam
    const = 2 * lam
    for (a, b), c in costs.items():
        Q[elems_a.index(a), nA + elems_b.index(b)] += c
    return Q, const


def energy(Q, const, idx):
    e = const
    for i in idx:
        e += Q[i, i]
    for p in range(len(idx)):
        for q in range(p + 1, len(idx)):
            i, j = sorted((idx[p], idx[q]))
            e += Q[i, j]
    return e


def anneal_pairs(Q, const, nA=52, nB=52, iters=200000, seed=SEED, t0=0.5, t1=0.002):
    """在可行域（A、B 各选一个）上做模拟退火，能量始终由矩阵计算。"""
    rng = np.random.default_rng(seed)
    i, j = int(rng.integers(0, nA)), int(rng.integers(0, nB))

    def energy_pair(i, j):
        return const + Q[i, i] + Q[nA + j, nA + j] + Q[i, nA + j]

    e = energy_pair(i, j)
    best, best_pair = e, (i, j)
    for k in range(iters):
        T = t0 * (t1 / t0) ** (k / iters)
        if rng.random() < 0.5:
            ni, nj = int(rng.integers(0, nA)), j
        else:
            ni, nj = i, int(rng.integers(0, nB))
        ne = energy_pair(ni, nj)
        if ne <= e or rng.random() < np.exp((e - ne) / T):
            i, j, e = ni, nj, ne
            if e < best - 1e-12:
                best, best_pair = e, (i, j)
    return best, best_pair


def anneal(Q, const, n, iters=300000, seed=SEED, t0=1.0, t1=0.005):
    """在 104 比特原始空间上做模拟退火，允许不可行态，用来交叉验证 QUBO 本身。"""
    rng = np.random.default_rng(seed)
    x = np.zeros(n, dtype=np.int8)
    x[rng.integers(0, 52)] = 1
    x[52 + rng.integers(0, 52)] = 1
    e = energy(Q, const, np.flatnonzero(x))
    best, best_x = e, x.copy()
    for k in range(iters):
        T = t0 * (t1 / t0) ** (k / iters)
        flip = int(rng.integers(0, n))
        # 上三角 Q：H = Σ Q_ii x_i + Σ_{i<j} Q_ij x_i x_j + const
        s = Q[flip, flip]
        if flip > 0:
            s += float(Q[:flip, flip] @ x[:flip])
        if flip + 1 < n:
            s += float(Q[flip, flip + 1:] @ x[flip + 1:])
        d = (1 - 2 * x[flip]) * s
        if d <= 0 or rng.random() < np.exp(-d / T):
            x[flip] ^= 1
            e += d
            if e < best - 1e-12:
                best, best_x = e, x.copy()
    return best, best_x


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--spec", default=None, help="指定 Q1 规格，读 pred_q2_<spec>.csv")
    ap.add_argument("--pred", default=None, help="直接指定预测表路径（官方 V1.2 导出）")
    ap.add_argument("--tag", default=None, help="输出文件名后缀，默认取 --spec")
    args = ap.parse_args()
    os.makedirs(OUT, exist_ok=True)
    if args.pred:
        pred_path = args.pred
    else:
        pred_path = os.path.join(RES, "pred_q2.csv" if not args.spec else f"pred_q2_{args.spec}.csv")
    if not os.path.exists(pred_path):
        sys.exit("先跑 venv-mirna/Scripts/python.exe run_q1.py 生成 pred_q2.csv")
    pool = pd.read_csv(pred_path, encoding="utf-8-sig")
    pool["id"] = pool["id"].astype(int)

    elems = sorted(set(pool["A"]) | set(pool["B"]))
    assert len(elems) == 52, len(elems)
    assert pool["A"].nunique() == 52 and pool["B"].nunique() == 52
    assert set(pool["X"]) == {"NO2"}, set(pool["X"])
    assert len(pool) == 2704, len(pool)

    raw = pool["V_hat"].to_numpy(float)
    lo, hi = float(raw.min()), float(raw.max())
    scaled = np.zeros_like(raw) if hi - lo < 1e-12 else (raw - lo) / (hi - lo)

    costs = {(a, b): float(c) for (a, b), c in
             zip(pool[["A", "B"]].itertuples(index=False, name=None), scaled)}
    Q, const = build_q2(costs, elems, elems)

    # 逐候选核对
    max_err, best_e, best_key = 0.0, np.inf, None
    for (a, b), c in costs.items():
        e = energy(Q, const, [elems.index(a), 52 + elems.index(b)])
        max_err = max(max_err, abs(e - c))
        if e < best_e:
            best_e, best_key = e, (a, b)

    k_star = min(costs, key=costs.get)
    assert k_star == best_key, (k_star, best_key)
    star_row = pool[(pool.A == k_star[0]) & (pool.B == k_star[1])].iloc[0]

    # 非法状态抽样：随机打乱后破坏一个独热约束
    rng = np.random.default_rng(SEED)
    illegal_min = np.inf
    for _ in range(20000):
        bits = np.zeros(104, dtype=np.int8)
        if rng.random() < 0.5:                      # 两个 A
            i, j = rng.choice(52, 2, replace=False)
            bits[i] = bits[j] = 1
        else:                                       # 两个 B
            i, j = rng.choice(52, 2, replace=False)
            bits[52 + i] = bits[52 + j] = 1
        bits[52 + rng.integers(0, 52)] = 1 if rng.random() < 0.5 else bits[52 + rng.integers(0, 52)]
        illegal_min = min(illegal_min, energy(Q, const, np.flatnonzero(bits)))

    sa_e, sa_pair = anneal_pairs(Q, const)
    sa_ok = abs(sa_e - best_e) < 1e-9 and (elems[sa_pair[0]], elems[sa_pair[1]]) == k_star

    report = {
        "problem": "Q2 (X = NO2)",
        "candidates": int(len(pool)),
        "variables": 104,
        "lambda": LAM,
        "scaling": {"lo": lo, "hi": hi},
        "max_energy_vs_cost": float(max_err),
        "oracle": {"A": k_star[0], "B": k_star[1],
                   "V_hat": float(star_row["V_hat"]),
                   "scaled_cost": float(costs[k_star]),
                   "energy": float(best_e)},
        "illegal_sample_min_energy": float(illegal_min),
        "sa": {"energy": float(sa_e), "feasible": bool(sa_ok)},
        "matrix": {"nnz": int(np.count_nonzero(Q)),
                   "abs_min": float(np.abs(Q[Q != 0]).min()),
                   "abs_max": float(np.abs(Q).max())},
        "top10": [
            {"A": a, "B": b, "V_hat": float(r), "scaled": float(c)}
            for (a, b), c, r in sorted(
                [(k, costs[k], float(pool[(pool.A == k[0]) & (pool.B == k[1])].iloc[0]["V_hat"]))
                 for k in costs], key=lambda t: t[1])[:10]
        ],
    }
    suffix = "" if not (args.tag or args.spec) else "_" + (args.tag or args.spec)
    with open(os.path.join(RES, f"q2_result{suffix}.json"), "w", encoding="utf-8") as fh:
        json.dump(report, fh, ensure_ascii=False, indent=2)

    np.savez_compressed(
        os.path.join(OUT, f"qubo_q2{suffix}.npz"),
        Q=Q, constant=np.array(const),
        convention=np.array("H(x)=x^T Q x + constant; Q 上三角；x∈{0,1}^104，前 52 为 A 位、后 52 为 B 位"),
        var_names=np.array([f"a:{e}" for e in elems] + [f"b:{e}" for e in elems]),
        candidate_A=pool["A"].to_numpy(), candidate_B=pool["B"].to_numpy(),
        candidate_id=pool["id"].to_numpy(),
        raw_scores=raw, scaled_scores=scaled,
        scaling=np.array([lo, hi]), penalty=np.array([LAM, LAM]),
        oracle_material=np.array([json.dumps(list(k_star))]),
        oracle_score=np.array([costs[k_star]]),
        oracle_raw_score=np.array([float(star_row["V_hat"])]),
        meta=np.array([json.dumps(report, ensure_ascii=False)]),
    )

    print(f"候选 {len(pool):,}｜变量 104｜max|E−cost| = {max_err:.1e}")
    print(f"最优：A={k_star[0]}, B={k_star[1]}｜V_hat={star_row['V_hat']:.4f}｜"
          f"缩放代价={costs[k_star]:.4f}｜能量={best_e:.4f}")
    print(f"非法抽样最小能量 = {illegal_min:.4f}（应 > {max(costs.values()):.4f}）")
    print(f"模拟退火：能量={sa_e:.4f}，可行={sa_ok}")
    print("已写：results/q2_result.json、matrices/qubo_q2.npz")


if __name__ == "__main__":
    main()
