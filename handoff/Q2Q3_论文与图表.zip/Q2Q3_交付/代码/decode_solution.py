﻿# -*- coding: utf-8 -*-
"""解码云平台返回的解（整数矩阵版）。

平台接受的是 8 位整数矩阵，返回的 quboValue 也是整数能量；
因此本地必须用同一张整数矩阵复算，才能与平台对账。

输入格式（两种都支持）：
  1. 平台导出的 JSON：[{"result":0,"quboValue":-1,"solutionVector":[1,1,0,1]}, ...]
  2. 纯文本 0/1 序列

用法：
    python decode_solution.py --meta platform_upload/qubo_q2_meta.json --solution q2_full_01.log
"""

import argparse
import json
import os
import re

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))


def load_solutions(path, n_expected=None):
    text = open(path, encoding="utf-8").read().strip()
    if text.startswith("["):
        data = json.loads(text)
        out = []
        for item in data:
            vec = item.get("solutionVector") or item.get("solution_vector")
            if vec is None:
                continue
            out.append((np.array(vec, dtype=int), item.get("quboValue")))
        return out
    nums = [int(x) for x in re.findall(r"(?<![\d.])[01](?![\d.])", text)]
    if n_expected and len(nums) % n_expected == 0 and len(nums) >= n_expected:
        return [(np.array(nums[i:i + n_expected], dtype=int), None)
                for i in range(0, len(nums), n_expected)]
    return [(np.array(nums, dtype=int), None)]


def integer_matrix(z, scale):
    Q = z["Q"].astype(float)
    return np.rint(Q * scale).astype(np.int64)


def energy_int(Qi, const_i, bits):
    idx = np.flatnonzero(bits)
    e = int(const_i)
    for i in idx:
        e += int(Qi[i, i])
    for a in range(len(idx)):
        for b in range(a + 1, len(idx)):
            i, j = sorted((idx[a], idx[b]))
            e += int(Qi[i, j])
    return e


def decode_one(problem, bits, names, nA=52, n_u=156, nX=3):
    ones = np.flatnonzero(bits)
    if problem == "q2":
        a_idx = [i for i in ones if i < nA]
        b_idx = [i for i in ones if i >= nA]
        if len(a_idx) == 1 and len(b_idx) == 1:
            return True, [names[a_idx[0]].split(":", 1)[1],
                          names[b_idx[0]].split(":", 1)[1]]
        return False, None
    u_idx = [i for i in ones if i < n_u]
    b_idx = [i for i in ones if i >= n_u]
    if len(u_idx) == 1 and len(b_idx) == 1:
        a, x = names[u_idx[0]].split(":", 1)[1].split("|")   # 直接用 u 变量的名字，避免下标换算出错
        return True, [a, names[b_idx[0]].split(":", 1)[1], x]
    return False, None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--meta", required=True)
    ap.add_argument("--solution", required=True)
    ap.add_argument("--topk", type=int, default=6)
    args = ap.parse_args()

    meta = json.load(open(args.meta, encoding="utf-8"))
    names = meta["variable_names"]
    scale = meta.get("scale", 1)
    const_i = meta.get("constant_integer", 0)
    problem = meta["problem"]

    z = np.load(os.path.join(HERE, "matrices", meta["source_npz"]), allow_pickle=True)
    Qi = integer_matrix(z, scale)
    raw = z["raw_scores"].astype(float) if "raw_scores" in z.files else None
    cand_a = z["candidate_A"].astype(str)
    cand_b = z["candidate_B"].astype(str)
    cand_x = z["candidate_X"].astype(str) if "candidate_X" in z.files else None

    # 原始排序（真实代理分）里的名次
    order_raw = np.argsort(raw, kind="stable") if raw is not None else None
    rank = {}
    if order_raw is not None:
        for r, i in enumerate(order_raw, 1):
            key = (cand_a[i], cand_b[i]) if problem == "q2" else (cand_a[i], cand_b[i], cand_x[i])
            rank.setdefault(key, r)

    sols = load_solutions(args.solution, len(names))
    rows = []
    for vec, qv in sols:
        if len(vec) != len(names):
            continue
        nA = len(meta.get("elements_A", [])) or 52
        n_u = (nA * len(meta.get("elements_X", []))) if meta.get("elements_X") else 156
        nX = len(meta.get("elements_X", [])) or 3
        ok, material = decode_one(problem, vec, names, nA, n_u, nX)
        e = energy_int(Qi, const_i, vec)
        key = tuple(material) if material else None
        rows.append({"material": material, "ok": ok, "energy_int": e,
                     "platform_qv": qv, "rank_raw": rank.get(key) if key else None})
    rows.sort(key=lambda r: r["energy_int"])

    print(f"变量 {len(names)}｜缩放 s={scale}｜常数项 {const_i}｜返回解 {len(rows)} 个")
    print(f"{'材料':<16}{'整数能量':>10}{'平台能量':>10}{'矩阵内名次':>12}  独热")
    for r in rows[:args.topk]:
        mat = "-".join(r["material"]) if r["material"] else "不合规"
        qv = "-" if r["platform_qv"] is None else f"{r['platform_qv']}"
        rk = "-" if r["rank_raw"] is None else f"{r['rank_raw']}"
        print(f"{mat:<16}{r['energy_int']:>10}{qv:>10}{rk:>12}  {r['ok']}")

    feasible = [r for r in rows if r["ok"]]
    if feasible:
        best = feasible[0]
        print(f"\n最优合规解：{best['material']}（整数能量 {best['energy_int']}，"
              f"原始 V̂ 排名第 {best['rank_raw']}）")
        score = {r["rank_raw"] for r in feasible if r["rank_raw"]}
        print(f"返回集合覆盖原始前 {max(score) if score else '?'} 名中的 "
              f"{len([r for r in feasible if r['rank_raw'] and r['rank_raw'] <= 5])} 个")
    else:
        print("⚠ 无合规解：检查矩阵约定或平台是否改动了罚系数")


if __name__ == "__main__":
    main()
