﻿# -*- coding: utf-8 -*-
"""问题三的真机版：短名单 + Ising 整数化。

编码：u_(A,X) 共 |A|×|X| 个 + B 位 |B| 个。
约束：2λ 与代价都取 4 的倍数，使 Ising 系数 J=q/4、h=q_ii/2+¼Σ(q_ik+q_ki) 全为整数；
      并控制 h 不超过 127。
"""

import json
import os

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
PRED = os.path.join(HERE, "data_official", "q3_pool_predictions.csv")
UP = os.path.join(HERE, "platform_upload")
MAT = os.path.join(HERE, "matrices")
RES = os.path.join(HERE, "results")
CAP = 0.3
LIMIT = 127


def ising(Q):
    S = Q + Q.T
    np.fill_diagonal(S, 0)
    h = np.diag(Q) / 2.0 + S.sum(axis=1) / 4.0
    J = np.triu(Q, k=1) / 4.0
    return h, J


def select(pool, n_top, per_x=3):
    """整体前 n_top + 每个 X 的前 per_x，保证三个 X 都进名单。"""
    a = pool.nsmallest(n_top, "V_hat")
    b = pd.concat([pool[pool["X"] == x].nsmallest(per_x, "V_hat")
                   for x in sorted(pool["X"].unique())])
    return pd.concat([a, b]).drop_duplicates(subset=["id"])


def build(pool, n_top, lam, cap=CAP):
    sub = select(pool, n_top)
    A = sorted(set(sub["A"]))
    B = sorted(set(sub["B"]))
    X = sorted(set(sub["X"]))
    grid = pool[pool["A"].isin(A) & pool["B"].isin(B) & pool["X"].isin(X)][
        ["A", "B", "X", "V_hat", "id"]].copy()
    ia = {e: i for i, e in enumerate(A)}
    ib = {e: i for i, e in enumerate(B)}
    ix = {x: k for k, x in enumerate(X)}
    nX = len(X)
    n_u = len(A) * nX
    n = n_u + len(B)

    raw = grid["V_hat"].to_numpy(float)
    lo = float(raw.min())
    levels = lam // 4
    clipped = np.minimum(raw, lo + cap)
    cost = np.clip(np.round((clipped - lo) / cap * levels).astype(int) * 4, 0, 4 * levels)

    Q = np.zeros((n, n), dtype=np.int64)
    Q[np.arange(n_u), np.arange(n_u)] = -lam
    Q[n_u + np.arange(len(B)), n_u + np.arange(len(B))] = -lam
    for i in range(n_u):
        for j in range(i + 1, n_u):
            Q[i, j] = 2 * lam
    for i in range(len(B)):
        for j in range(i + 1, len(B)):
            Q[n_u + i, n_u + j] = 2 * lam
    for (a, x, b), c in zip(grid[["A", "X", "B"]].itertuples(index=False, name=None), cost):
        Q[ia[a] * nX + ix[x], n_u + ib[b]] += int(c)

    idx = np.array([(ia[a] * nX + ix[x], n_u + ib[b])
                    for a, x, b in grid[["A", "X", "B"]].itertuples(index=False, name=None)])
    e = Q[idx[:, 0], idx[:, 0]] + Q[idx[:, 1], idx[:, 1]] + Q[idx[:, 0], idx[:, 1]]
    o = int(np.argmin(e))
    material = (grid.iloc[o]["A"], grid.iloc[o]["B"], grid.iloc[o]["X"])
    true_best = tuple(grid.iloc[int(np.argmin(raw))][["A", "B", "X"]])
    return dict(Q=Q, A=A, B=B, X=X, grid=grid, lam=lam, levels=levels,
                material=material, true_best=true_best, ok=material == true_best,
                ties=int(np.sum(e == e[o])), navi=len(B), nx=nX, lsb=cap / levels)


def main():
    pool = pd.read_csv(PRED, encoding="utf-8-sig")
    rows, best = [], None
    for n_top in (3, 4, 6):
        for lam in (8, 12):
            r = build(pool, n_top, lam)
            h, J = ising(r["Q"])
            int_ok = bool(np.allclose(h, np.round(h)) and np.allclose(J, np.round(J)))
            mh, mJ = float(np.abs(h).max()), float(np.abs(J).max())
            r.update(max_h=mh, max_J=mJ, integer_ising=int_ok, n_top=n_top)
            rows.append(r)
            # Q3 的首位间隔只有 0.0131，8 位下必然无法唯一区分；
            # 因此选型标准改为「整数可行 + h 不超限 + 代价档位最多」，并如实报告并列。
            if int_ok and mh <= 110:
                score = (r["levels"], n_top)
                if best is None or score > best["score"]:
                    best = dict(r, score=score)

    print(f"{'top':>4} {'λ':>3} {'|A|×|X|+|B|':>12} {'|h|':>6} {'|J|':>4} 整数 解 ok")
    for r in sorted(rows, key=lambda x: (not x["integer_ising"], -x["n_top"], x["max_h"]))[:8]:
        print(f"{r['n_top']:>4} {r['lam']:>3} {r['Q'].shape[0]:>12} {r['max_h']:>6.1f} "
              f"{r['max_J']:>4.1f} {str(r['integer_ising']):>5} "
              f"{'-'.join(r['material'])} {r['ok']}")

    with open(os.path.join(RES, "q3_intising_scan.json"), "w", encoding="utf-8") as fh:
        json.dump([{k: v for k, v in r.items() if k not in ("Q", "grid")} for r in rows],
                  fh, ensure_ascii=False, indent=2)
    if best is None:
        print("无可行组合；需要进一步缩名单或换拆分")
        return

    Q, lam = best["Q"], best["lam"]
    grid = best["grid"]
    const = 2 * lam
    np.savetxt(os.path.join(UP, "qubo_q3_intising.csv"), Q, delimiter=",", fmt="%d")
    names = [f"u:{a}|{x}" for a in best["A"] for x in best["X"]] + [f"b:{b}" for b in best["B"]]
    np.savez_compressed(
        os.path.join(MAT, "qubo_q3_intising.npz"),
        Q=Q.astype(float), constant=np.array(const),
        var_names=np.array(names),
        candidate_A=grid["A"].to_numpy(), candidate_B=grid["B"].to_numpy(),
        candidate_X=grid["X"].to_numpy(), candidate_id=grid["id"].to_numpy(),
        raw_scores=grid["V_hat"].to_numpy(float),
        oracle_material=np.array([json.dumps(list(best["true_best"]))]),
        oracle_raw_score=np.array([float(grid["V_hat"].min())]),
        elements_A=np.array(best["A"]), elements_B=np.array(best["B"]),
        elements_X=np.array(best["X"]),
    )
    meta = {
        "problem": "q3", "tag": "intising", "source_npz": "qubo_q3_intising.npz",
        "variables": int(Q.shape[0]), "scale": 1, "constant_integer": const,
        "convention": "H=xᵀQx+constant；上三角；整数；u_(A,X) 在前（a*|X|+k），B 在后",
        "elements_A": best["A"], "elements_B": best["B"], "elements_X": best["X"],
        "variable_names": names, "n_candidates": int(len(grid)),
        "lambda": lam, "cost_bins": best["levels"],
        "cost_lsb_raw": round(best["lsb"], 5),
        "max_abs_ising_h": round(best["max_h"], 3),
        "max_abs_ising_J": round(best["max_J"], 3),
        "integer_ising": True, "raw_argmin": list(best["true_best"]),
    }
    with open(os.path.join(UP, "qubo_q3_intising_meta.json"), "w", encoding="utf-8") as fh:
        json.dump(meta, fh, ensure_ascii=False, indent=2)
    with open(os.path.join(RES, "q3_intising_scan.json"), "w", encoding="utf-8") as fh:
        json.dump([{k: v for k, v in r.items() if k not in ("Q", "grid")} for r in rows],
                  fh, ensure_ascii=False, indent=2)

    print(f"\n采用 top{best['n_top']}、λ={lam}：{Q.shape[0]} 变量（|A|={len(best['A'])}, "
          f"|X|={best['nx']}, |B|={len(best['B'])}），|h|={best['max_h']:.0f}, "
          f"|J|={best['max_J']:.0f}，候选 {len(grid)}，最优 {best['material']}")
    print("已写 platform_upload/qubo_q3_intising.csv 与 _meta.json")


if __name__ == "__main__":
    main()
