# 问题二 / 问题三 论文草稿与图表

打包时间：2026-11-27 19:13

## 目录

```
Q2Q3_交付/
├── 论文_Q2Q3_章节草稿.docx   可直接编辑（Word）
├── 论文_Q2Q3_章节草稿.md     纯文本版，便于比对
├── 图/                       4 张 300 dpi 插图
├── 数据/                     结果 JSON、真机日志、量化分析
├── 矩阵/                     4 个 QUBO 矩阵（全池 / 8 位 / 短名单）
└── 代码/                     复现脚本
```

## 四个图对应正文哪里

| 图 | 文件 | 支撑的结论 |
|---|---|---|
| 图 1 | `图/fig1_q2_top10.png` | 问题二最优 Y–Ti，$\hat V$=1.49193，领先第二名 0.31382 |
| 图 2 | `图/fig2_q3_by_x.png` | 问题三 O3 组最优 0.54002（NO2 1.49193 / FO2 0.87853） |
| 图 3 | `图/fig3_machine_samples.png` | SPQC-550 十次采样：1 个合法最优 −40，9 个非法 ≥628 |
| 图 4 | `图/fig4_quantization.png` | 8 位下全量矩阵最低档并列 6 个；截断后并列 1 个 |

## 关键数字的来源

| 数字 | 来源文件 |
|---|---|
| Q2 最优 Y–Ti，1.49193 | `数据/q2_result_official_v12.json` |
| Q3 最优 Na–Nb–O3，0.54002 | `数据/q3_result_official_v12.json` |
| 2,704 / 8,112 个候选的能量逐条相等 | `数据/q2_result_official_v12.json`、`q3_result_official_v12.json` 的 `max_energy_vs_cost` |
| 8 位下并列数与 LSB | `数据/quantization_check.json` |
| Q2 8 位可用版（Δ=0.4）| `数据/q2_8bit_ready.json` |
| Q3 8 位可用版（Δ=0.4）| `数据/q3_8bit_ready.json` |
| SPQC-550 两次任务的返回解 | `数据/q2_int_01.log`、`数据/q3_int_01.log` |
| 矩阵数值范围（−62~124 等）| `数据/platform_int_matrices.json` |

## 两次真机任务

| | Q2（q2_int_01） | Q3（q3_int_01） |
|---|---|---|
| 矩阵 | 17 变量，`|h|`max=110 | 30 变量，`|h|`max=100 |
| 创建→结束 | 4 秒 | 19 秒 |
| 单次演化 | 1.1228 ms | 8.7755 ms |
| 返回 | Y–Ti（全局最优） | Ge–Ti–O3（X=O3，A–B 精度受限） |

## 复现命令

```bash
# 用官方预测重建全池矩阵并验证
python 代码/q2_qubo.py --pred <q2_pool_predictions.csv> --tag official_v12
python 代码/q3_qubo.py --pred <q3_pool_predictions.csv> --tag official_v12

# 8 位量化分析与可用版
python 代码/export_platform_int.py
python 代码/q2_intising_qubo.py
python 代码/q3_intising_qubo.py

# 解码真机日志
python 代码/decode_solution.py --meta <meta.json> --solution 数据/q2_int_01.log

# 重画四张图
venv-mirna/Scripts/python.exe 代码/make_figures.py
```

## 提醒

1. 论文里的“最优”都是**代理目标**下的最优，真实物性以主办方盲测评分为准；
2. 问题三真机只能确认 X = O3，A–B 因 0.013~0.064 的间隔小于 8 位分辨率而无法唯一确定；
3. 两次任务排队时间均接近零，属当时机器空闲的单次观测，不代表赛事高峰常态。
